import React from "react";
import PropTypes from "prop-types";

const Quadrant = ({ bgColor, children }) => (
  <div className="quadrant" style={{ backgroundColor: bgColor }}>
    {children}
  </div>
);

Quadrant.propTypes = {
  bgColor: PropTypes.string.isRequired,
  children: PropTypes.any,
};

export default Quadrant;
