import React, { useState } from "react";
import PropTypes from "prop-types";

const Mouse = ({ render }) => {
  const [mouse, setMouse] = useState({ xAxis: 0, yAxis: 0 });
  let wrapRef = null;

  const getCordinates = () => {
    let rect = wrapRef.firstChild.getBoundingClientRect();
    return {
      x: Math.floor(rect.left),
      y: Math.floor(rect.top),
    };
  };

  const handleMouseTrack = (e) => {
    let cordinates = getCordinates();
    setMouse({
      xAxis: e.clientX - cordinates.x,
      yAxis: e.clientY - cordinates.y,
    });
  };

  return (
    <span
      onMouseMove={handleMouseTrack}
      ref={(el) => (wrapRef = el)}
      style={{ minWidth: "50%", height: "50%" }}
    >
      {render(mouse)}
    </span>
  );
};
Mouse.prototype = {
  render: PropTypes.func.isRequired,
};
export default Mouse;
