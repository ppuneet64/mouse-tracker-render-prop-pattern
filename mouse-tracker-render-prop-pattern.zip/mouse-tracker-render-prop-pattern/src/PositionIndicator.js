import React from "react";
import PropTypes from "prop-types";

const PositionIndicator = ({ xAxis, yAxis, color = "red" }) => (
  <div
    style={{ top: yAxis, left: xAxis, backgroundColor: color }}
    className="circle-element"
  ></div>
);

PositionIndicator.propTypes = {
  xAxis: PropTypes.number.isRequired,
  yAxis: PropTypes.number.isRequired,
  color: PropTypes.string.isRequired
};

export default PositionIndicator;
