import React from "react";
import PropTypes from "prop-types";

const Coordinates = ({ xAxis = 0, yAxis = 0 }) => (
  <span>
    Coordinates: <br />
    X:{xAxis}, Y:{yAxis}
  </span>
);

Coordinates.propTypes = {
  xAxis: PropTypes.number.isRequired,
  yAxis: PropTypes.number.isRequired,
};
export default Coordinates;
