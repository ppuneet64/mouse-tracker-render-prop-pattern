import React from "react";
import "./styles.css";
import Quadrant from "./Quadrant";
import PositionIndicator from "./PositionIndicator";
import Coordinates from "./Coordinates";
import Mouse from "./Mouse";

export default function App() {
  return (
    <div className="quadrant-container">
      <Mouse
        render={(mouse) => (
          <Quadrant bgColor="pink">
            <Coordinates {...mouse} />
            <PositionIndicator color="red" {...mouse} />
          </Quadrant>
        )}
      />
      <Mouse
        render={(mouse) => (
          <Quadrant bgColor="#666666">
            <Coordinates {...mouse} />
            <PositionIndicator color="#fff" {...mouse} />
          </Quadrant>
        )}
      />
      <Mouse
        render={(mouse) => (
          <Quadrant bgColor="powderblue">
            <Coordinates {...mouse} />
            <PositionIndicator color="blue" {...mouse} />
          </Quadrant>
        )}
      />
      <Mouse
        render={(mouse) => (
          <Quadrant bgColor="yellow">
            <Coordinates {...mouse} />
            <PositionIndicator color="goldenrod" {...mouse} />
          </Quadrant>
        )}
      />
    </div>
  );
}
